const phone = "01760355096";
const whatsapp = "8801760355096";

const services = [
  {
    icon: "⚡",
    title: "Electric Service",
    bn: "ইলেকট্রিক সার্ভিস",
    description: "বাড়ি ও অফিসের ওয়্যারিং, সুইচ-সকেট, লাইট এবং বৈদ্যুতিক সমস্যা মেরামত।",
  },
  {
    icon: "❄️",
    title: "AC Servicing",
    bn: "এসি সার্ভিসিং",
    description: "এসি পরিষ্কার, ইনস্টলেশন, সাধারণ মেরামত এবং কুলিং সমস্যা পরীক্ষা।",
  },
  {
    icon: "🚰",
    title: "Plumbing Service",
    bn: "প্লাম্বিং সার্ভিস",
    description: "পানির কল, পাইপ, বেসিন এবং পানির লিকেজ মেরামত।",
  },
  {
    icon: "🧱",
    title: "Wall Repairing",
    bn: "দেয়াল মেরামত",
    description: "দেয়ালের ফাটল, প্লাস্টার, পুটি, রং এবং স্যাঁতসেঁতে দেয়াল মেরামতের কাজ।",
  },
];

export default function Home() {
  return (
    <main>
      <header className="topbar">
        <a className="brand" href="#home">
          <span className="brandIcon">🛠️</span>
          <span>Faruk <b>Electric & AC Servicing</b></span>
        </a>
        <a className="callSmall" href={`tel:${phone}`}>কল করুন</a>
      </header>

      <section className="hero" id="home">
        <div className="heroContent">
          <p className="eyebrow">TRUSTED HOME SERVICE</p>
          <h1>আপনার বাড়ির সার্ভিস, <span>এক জায়গায়</span></h1>
          <p className="heroText">
            ইলেকট্রিক, এসি সার্ভিসিং, প্লাম্বিং ও দেয়াল মেরামতের জন্য যোগাযোগ করুন।
            আমরা বাংলাদেশজুড়ে সার্ভিস বুকিংয়ের অনুরোধ গ্রহণ করি।
          </p>
          <div className="heroActions">
            <a className="button primary" href={`tel:${phone}`}>📞 ফোন করে বুকিং</a>
            <a className="button whatsapp" href={`https://wa.me/${whatsapp}?text=${encodeURIComponent("আমি সার্ভিস বুক করতে চাই।")}`} target="_blank" rel="noreferrer">WhatsApp বুকিং</a>
          </div>
          <p className="phoneLine">যোগাযোগ: <strong>{phone}</strong></p>
        </div>
        <div className="heroArt" aria-label="বাড়ির সার্ভিসের প্রতীক">
          <div className="artCircle">🏠</div>
          <div className="floatingBadge badgeOne">⚡ Electric</div>
          <div className="floatingBadge badgeTwo">❄️ AC Service</div>
          <div className="floatingBadge badgeThree">🚰 Plumbing</div>
        </div>
      </section>

      <section className="services section" id="services">
        <div className="sectionHeading">
          <p className="eyebrow">OUR SERVICES</p>
          <h2>আমাদের সার্ভিসসমূহ</h2>
          <p>আপনার প্রয়োজনীয় সার্ভিস নির্বাচন করে বুকিং দিন।</p>
        </div>
        <div className="serviceGrid">
          {services.map((service) => (
            <article className="serviceCard" key={service.title}>
              <div className="serviceIcon">{service.icon}</div>
              <h3>{service.bn}</h3>
              <p className="englishTitle">{service.title}</p>
              <p>{service.description}</p>
              <a href={`https://wa.me/${whatsapp}?text=${encodeURIComponent("আমি " + service.bn + " বুক করতে চাই।")}`} target="_blank" rel="noreferrer" className="textLink">
                এই সার্ভিস বুক করুন →
              </a>
            </article>
          ))}
        </div>
      </section>

      <section className="booking section" id="booking">
        <div>
          <p className="eyebrow">BOOK A SERVICE</p>
          <h2>সার্ভিস বুক করতে প্রস্তুত?</h2>
          <p>ফোন করুন অথবা WhatsApp-এ আপনার সমস্যা ও ঠিকানা লিখে পাঠান। কাজের মূল্য কাজের ধরন অনুযায়ী নিশ্চিত করা হবে।</p>
        </div>
        <div className="bookingActions">
          <a className="button primary" href={`tel:${phone}`}>📞 {phone}</a>
          <a className="button whatsapp" href={`https://wa.me/${whatsapp}?text=${encodeURIComponent("আমি Faruk Electric & AC Servicing থেকে সার্ভিস নিতে চাই।")}`} target="_blank" rel="noreferrer">WhatsApp-এ মেসেজ দিন</a>
        </div>
      </section>

      <footer>
        <div className="footerBrand">Faruk Electric & AC Servicing</div>
        <p>Electric • AC Servicing • Plumbing • Wall Repairing</p>
        <p>সার্ভিস এলাকা: বাংলাদেশজুড়ে</p>
        <p>ফোন: <a href={`tel:${phone}`}>{phone}</a></p>
        <small>© {new Date().getFullYear()} Faruk Electric & AC Servicing. All rights reserved.</small>
      </footer>

      <a className="floatingWhatsApp" href={`https://wa.me/${whatsapp}`} target="_blank" rel="noreferrer" aria-label="WhatsApp-এ যোগাযোগ">☏</a>
    </main>
  );
}
