import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Faruk Electric & AC Servicing",
  description: "Electric, AC, plumbing and wall repairing services across Bangladesh.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="bn">
      <body>{children}</body>
    </html>
  );
}
