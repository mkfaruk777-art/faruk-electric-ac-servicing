# Faruk Electric & AC Servicing — Next.js Website

## Included services
- Electric Service
- AC Servicing
- Plumbing Service
- Wall Repairing

## Contact
Phone / WhatsApp: 01760355096

## Important
This is a fresh project folder. Keep your old project as a backup and do not delete it until this new project runs correctly.

## Run on a computer
1. Install Node.js (LTS).
2. Extract this ZIP.
3. Open a terminal in this folder.
4. Run `npm install`
5. Run `npm run dev`
6. Open `http://localhost:3000`

## Android note
You can download and keep the ZIP on your Android phone, but a Next.js project generally needs a Node.js environment or online hosting to run. To preview it on your phone, you can upload the project to a compatible online coding/hosting service.
